import { EventSource } from "@godspeedsystems/plugins-express-as-http";

export default EventSource;
